let btn1 = document.querySelector('.btn1');

let success = ()=>{
   btn1.innerHTML =    `Success<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill ms-2" viewBox="0 0 16 16">
   <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
 </svg>` 
   btn1.classList.add('btn');
}
let error = ()=>{
   btn1.innerHTML = `Error! Retry <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="ms-1 bi bi-arrow-clockwise" viewBox="0 0 16 16">
   <path fill-rule="evenodd" d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2v1z"/>
   <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466z"/>
 </svg>`
   btn1.classList.add('btn');
}
let checkbox = document.querySelector('#flexSwitchCheckDefault');

checkbox.addEventListener('change', function() {

   if(this.checked) {
      btn1.innerHTML = 'Send Current Tab'
   } else {
      btn1.innerHTML = 'Send All Tabs'
   }
});
btn1.addEventListener('click', function() {

   if(btn1.querySelector('.loading')){
      return;
   }



if(checkbox.checked){

   chrome.runtime.sendMessage({ action: 'currentTab' }, response => { 
      
      chrome.storage.local.get(['urls'], result => {
 let urls =[ result.urls].filter(url => {
         url = url.trim();
        if( url.indexOf('chrome') == 0 || url.indexOf('edge')==0){
           return false;
        }else{
           return true;
        }
        })
        || [];
  
  
       if(!(urls.length > 0)){
           alert('no open tabs');
        return;
       }
  
      btn1.innerHTML = `	<div class="loading"></div>    `
      btn1.classList.remove('btn');
  
  
  fetch('https://tabs.aquafusion.in/urls', { 
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ urls })
  }).then(res => res.json()).then(data => {
     if(data!=='success'){
  throw new Error('error');
     }
   success();
   setTimeout(() => {
      chrome.tabs.reload(response.tabs);
      
      }, 300);
   
  }).catch(err => {
     error();
    
  });
  
     
  
  
      });
     });



}else{

   chrome.runtime.sendMessage({ action: 'buttonClicked' }, response => { 

   

    chrome.storage.local.get(['urls'], result => {

      const urls = result.urls.filter(url => {
       url = url.trim();
      if( url.indexOf('chrome') == 0 || url.indexOf('edge')==0){
         return false;
      }else{
         return true;
      }
      })
      || [];


     if(!(urls.length > 0)){
         alert('no open tabs');
      return;
     }

    btn1.innerHTML = `	<div class="loading"></div>    `
    btn1.classList.remove('btn');


fetch('https://tabs.aquafusion.in/urls', { 
method: 'POST',
headers: { 'Content-Type': 'application/json' },
body: JSON.stringify({ urls })
}).then(res => res.json()).then(data => {
  
   if(data!='success'){
      
throw new Error('error');

   }
 success();
 setTimeout(() => {
   chrome.tabs.reload(response.tabs);

   }, 300);
 
   
}).catch(err => {
   error();
  
});

   


    });
   });
}

});


