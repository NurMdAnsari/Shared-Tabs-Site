chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'buttonClicked') {
   let reloadtabs;
   
        
    chrome.tabs.query({}, tabs => {
      const urls = tabs.map(tab => tab.url);
      chrome.storage.local.set({ urls: urls },async () => {

     tabs.forEach(each => {
      if(each.url === 'https://tabs.aquafusion.in'){
        reloadtabs = each.id;
     }
     });
      
        sendResponse({ message: 'Data saved successfully',tabs:reloadtabs });
       
      });
    });
    return true; // This tells Chrome that the response will be sent asynchronously

  }else if(message.action === 'currentTab'){
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs.length > 0) {
        const currentTab = tabs[0];
        const url = currentTab.url;
        chrome.storage.local.set({ urls: url }, () => {
          //
          let reloadtabs;
  chrome.tabs.query({}, tabs => {
  
     tabs.forEach(each => {
      if(each.url === 'https://tabs.aquafusion.in'){
        reloadtabs = each.id;
       
     }
     }); 
     sendResponse({ message: 'Data saved successfully',tabs:reloadtabs })
    });
          //
          ;
        });
      } else {
        console.log('No active tabs found.');
      }
    });
    
return true; // This tells Chrome that the response will be sent asynchronously
  }
});

